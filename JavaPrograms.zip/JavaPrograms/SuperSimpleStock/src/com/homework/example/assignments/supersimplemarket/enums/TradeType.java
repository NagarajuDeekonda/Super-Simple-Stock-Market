package com.homework.example.assignments.supersimplemarket.enums;

/** Trade Types **/
public enum TradeType {
	BUY, SELL
}