package com.homework.example.assignments.supersimplemarket.enums;

/** Stock Types **/
public enum StockType {
	COMMON, PREFERRED
}